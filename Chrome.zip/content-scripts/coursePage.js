/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 793:
/***/ ((module) => {


function tryStringify (o) {
  try { return JSON.stringify(o) } catch(e) { return '"[Circular]"' }
}

module.exports = format

function format(f, args, opts) {
  var ss = (opts && opts.stringify) || tryStringify
  var offset = 1
  if (typeof f === 'object' && f !== null) {
    var len = args.length + offset
    if (len === 1) return f
    var objects = new Array(len)
    objects[0] = ss(f)
    for (var index = 1; index < len; index++) {
      objects[index] = ss(args[index])
    }
    return objects.join(' ')
  }
  if (typeof f !== 'string') {
    return f
  }
  var argLen = args.length
  if (argLen === 0) return f
  var str = ''
  var a = 1 - offset
  var lastPos = -1
  var flen = (f && f.length) || 0
  for (var i = 0; i < flen;) {
    if (f.charCodeAt(i) === 37 && i + 1 < flen) {
      lastPos = lastPos > -1 ? lastPos : 0
      switch (f.charCodeAt(i + 1)) {
        case 100: // 'd'
        case 102: // 'f'
          if (a >= argLen)
            break
          if (args[a] == null)  break
          if (lastPos < i)
            str += f.slice(lastPos, i)
          str += Number(args[a])
          lastPos = i + 2
          i++
          break
        case 105: // 'i'
          if (a >= argLen)
            break
          if (args[a] == null)  break
          if (lastPos < i)
            str += f.slice(lastPos, i)
          str += Math.floor(Number(args[a]))
          lastPos = i + 2
          i++
          break
        case 79: // 'O'
        case 111: // 'o'
        case 106: // 'j'
          if (a >= argLen)
            break
          if (args[a] === undefined) break
          if (lastPos < i)
            str += f.slice(lastPos, i)
          var type = typeof args[a]
          if (type === 'string') {
            str += '\'' + args[a] + '\''
            lastPos = i + 2
            i++
            break
          }
          if (type === 'function') {
            str += args[a].name || '<anonymous>'
            lastPos = i + 2
            i++
            break
          }
          str += ss(args[a])
          lastPos = i + 2
          i++
          break
        case 115: // 's'
          if (a >= argLen)
            break
          if (lastPos < i)
            str += f.slice(lastPos, i)
          str += String(args[a])
          lastPos = i + 2
          i++
          break
        case 37: // '%'
          if (lastPos < i)
            str += f.slice(lastPos, i)
          str += '%'
          lastPos = i + 2
          i++
          a--
          break
      }
      ++a
    }
    ++i
  }
  if (lastPos === -1)
    return f
  else if (lastPos < flen) {
    str += f.slice(lastPos)
  }

  return str
}


/***/ }),

/***/ 4874:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



const format = __webpack_require__(793)

module.exports = pino

const _console = pfGlobalThisOrFallback().console || {}
const stdSerializers = {
  mapHttpRequest: mock,
  mapHttpResponse: mock,
  wrapRequestSerializer: passthrough,
  wrapResponseSerializer: passthrough,
  wrapErrorSerializer: passthrough,
  req: mock,
  res: mock,
  err: asErrValue,
  errWithCause: asErrValue
}
function levelToValue (level, logger) {
  return level === 'silent'
    ? Infinity
    : logger.levels.values[level]
}
const baseLogFunctionSymbol = Symbol('pino.logFuncs')
const hierarchySymbol = Symbol('pino.hierarchy')

const logFallbackMap = {
  error: 'log',
  fatal: 'error',
  warn: 'error',
  info: 'log',
  debug: 'log',
  trace: 'log'
}

function appendChildLogger (parentLogger, childLogger) {
  const newEntry = {
    logger: childLogger,
    parent: parentLogger[hierarchySymbol]
  }
  childLogger[hierarchySymbol] = newEntry
}

function setupBaseLogFunctions (logger, levels, proto) {
  const logFunctions = {}
  levels.forEach(level => {
    logFunctions[level] = proto[level] ? proto[level] : (_console[level] || _console[logFallbackMap[level] || 'log'] || noop)
  })
  logger[baseLogFunctionSymbol] = logFunctions
}

function shouldSerialize (serialize, serializers) {
  if (Array.isArray(serialize)) {
    const hasToFilter = serialize.filter(function (k) {
      return k !== '!stdSerializers.err'
    })
    return hasToFilter
  } else if (serialize === true) {
    return Object.keys(serializers)
  }

  return false
}

function pino (opts) {
  opts = opts || {}
  opts.browser = opts.browser || {}

  const transmit = opts.browser.transmit
  if (transmit && typeof transmit.send !== 'function') { throw Error('pino: transmit option must have a send function') }

  const proto = opts.browser.write || _console
  if (opts.browser.write) opts.browser.asObject = true
  const serializers = opts.serializers || {}
  const serialize = shouldSerialize(opts.browser.serialize, serializers)
  let stdErrSerialize = opts.browser.serialize

  if (
    Array.isArray(opts.browser.serialize) &&
    opts.browser.serialize.indexOf('!stdSerializers.err') > -1
  ) stdErrSerialize = false

  const customLevels = Object.keys(opts.customLevels || {})
  const levels = ['error', 'fatal', 'warn', 'info', 'debug', 'trace'].concat(customLevels)

  if (typeof proto === 'function') {
    levels.forEach(function (level) {
      proto[level] = proto
    })
  }
  if (opts.enabled === false || opts.browser.disabled) opts.level = 'silent'
  const level = opts.level || 'info'
  const logger = Object.create(proto)
  if (!logger.log) logger.log = noop

  setupBaseLogFunctions(logger, levels, proto)
  // setup root hierarchy entry
  appendChildLogger({}, logger)

  Object.defineProperty(logger, 'levelVal', {
    get: getLevelVal
  })
  Object.defineProperty(logger, 'level', {
    get: getLevel,
    set: setLevel
  })

  const setOpts = {
    transmit,
    serialize,
    asObject: opts.browser.asObject,
    levels,
    timestamp: getTimeFunction(opts)
  }
  logger.levels = getLevels(opts)
  logger.level = level

  logger.setMaxListeners = logger.getMaxListeners =
  logger.emit = logger.addListener = logger.on =
  logger.prependListener = logger.once =
  logger.prependOnceListener = logger.removeListener =
  logger.removeAllListeners = logger.listeners =
  logger.listenerCount = logger.eventNames =
  logger.write = logger.flush = noop
  logger.serializers = serializers
  logger._serialize = serialize
  logger._stdErrSerialize = stdErrSerialize
  logger.child = child

  if (transmit) logger._logEvent = createLogEventShape()

  function getLevelVal () {
    return levelToValue(this.level, this)
  }

  function getLevel () {
    return this._level
  }
  function setLevel (level) {
    if (level !== 'silent' && !this.levels.values[level]) {
      throw Error('unknown level ' + level)
    }
    this._level = level

    set(this, setOpts, logger, 'error') // <-- must stay first
    set(this, setOpts, logger, 'fatal')
    set(this, setOpts, logger, 'warn')
    set(this, setOpts, logger, 'info')
    set(this, setOpts, logger, 'debug')
    set(this, setOpts, logger, 'trace')

    customLevels.forEach((level) => {
      set(this, setOpts, logger, level)
    })
  }

  function child (bindings, childOptions) {
    if (!bindings) {
      throw new Error('missing bindings for child Pino')
    }
    childOptions = childOptions || {}
    if (serialize && bindings.serializers) {
      childOptions.serializers = bindings.serializers
    }
    const childOptionsSerializers = childOptions.serializers
    if (serialize && childOptionsSerializers) {
      var childSerializers = Object.assign({}, serializers, childOptionsSerializers)
      var childSerialize = opts.browser.serialize === true
        ? Object.keys(childSerializers)
        : serialize
      delete bindings.serializers
      applySerializers([bindings], childSerialize, childSerializers, this._stdErrSerialize)
    }
    function Child (parent) {
      this._childLevel = (parent._childLevel | 0) + 1

      // make sure bindings are available in the `set` function
      this.bindings = bindings

      if (childSerializers) {
        this.serializers = childSerializers
        this._serialize = childSerialize
      }
      if (transmit) {
        this._logEvent = createLogEventShape(
          [].concat(parent._logEvent.bindings, bindings)
        )
      }
    }
    Child.prototype = this
    const newLogger = new Child(this)

    // must happen before the level is assigned
    appendChildLogger(this, newLogger)
    // required to actually initialize the logger functions for any given child
    newLogger.level = this.level

    return newLogger
  }
  return logger
}

function getLevels (opts) {
  const customLevels = opts.customLevels || {}

  const values = Object.assign({}, pino.levels.values, customLevels)
  const labels = Object.assign({}, pino.levels.labels, invertObject(customLevels))

  return {
    values,
    labels
  }
}

function invertObject (obj) {
  const inverted = {}
  Object.keys(obj).forEach(function (key) {
    inverted[obj[key]] = key
  })
  return inverted
}

pino.levels = {
  values: {
    fatal: 60,
    error: 50,
    warn: 40,
    info: 30,
    debug: 20,
    trace: 10
  },
  labels: {
    10: 'trace',
    20: 'debug',
    30: 'info',
    40: 'warn',
    50: 'error',
    60: 'fatal'
  }
}

pino.stdSerializers = stdSerializers
pino.stdTimeFunctions = Object.assign({}, { nullTime, epochTime, unixTime, isoTime })

function getBindingChain (logger) {
  const bindings = []
  if (logger.bindings) {
    bindings.push(logger.bindings)
  }

  // traverse up the tree to get all bindings
  let hierarchy = logger[hierarchySymbol]
  while (hierarchy.parent) {
    hierarchy = hierarchy.parent
    if (hierarchy.logger.bindings) {
      bindings.push(hierarchy.logger.bindings)
    }
  }

  return bindings.reverse()
}

function set (self, opts, rootLogger, level) {
  // override the current log functions with either `noop` or the base log function
  self[level] = levelToValue(self.level, rootLogger) > levelToValue(level, rootLogger)
    ? noop
    : rootLogger[baseLogFunctionSymbol][level]

  if (!opts.transmit && self[level] === noop) {
    return
  }

  // make sure the log format is correct
  self[level] = createWrap(self, opts, rootLogger, level)

  // prepend bindings if it is not the root logger
  const bindings = getBindingChain(self)
  if (bindings.length === 0) {
    // early exit in case for rootLogger
    return
  }
  self[level] = prependBindingsInArguments(bindings, self[level])
}

function prependBindingsInArguments (bindings, logFunc) {
  return function () {
    return logFunc.apply(this, [...bindings, ...arguments])
  }
}

function createWrap (self, opts, rootLogger, level) {
  return (function (write) {
    return function LOG () {
      const ts = opts.timestamp()
      const args = new Array(arguments.length)
      const proto = (Object.getPrototypeOf && Object.getPrototypeOf(this) === _console) ? _console : this
      for (var i = 0; i < args.length; i++) args[i] = arguments[i]

      if (opts.serialize && !opts.asObject) {
        applySerializers(args, this._serialize, this.serializers, this._stdErrSerialize)
      }
      if (opts.asObject) write.call(proto, asObject(this, level, args, ts))
      else write.apply(proto, args)

      if (opts.transmit) {
        const transmitLevel = opts.transmit.level || self._level
        const transmitValue = rootLogger.levels.values[transmitLevel]
        const methodValue = rootLogger.levels.values[level]
        if (methodValue < transmitValue) return
        transmit(this, {
          ts,
          methodLevel: level,
          methodValue,
          transmitLevel,
          transmitValue: rootLogger.levels.values[opts.transmit.level || self._level],
          send: opts.transmit.send,
          val: levelToValue(self._level, rootLogger)
        }, args)
      }
    }
  })(self[baseLogFunctionSymbol][level])
}

function asObject (logger, level, args, ts) {
  if (logger._serialize) applySerializers(args, logger._serialize, logger.serializers, logger._stdErrSerialize)
  const argsCloned = args.slice()
  let msg = argsCloned[0]
  const o = {}
  if (ts) {
    o.time = ts
  }
  o.level = logger.levels.values[level]
  let lvl = (logger._childLevel | 0) + 1
  if (lvl < 1) lvl = 1
  // deliberate, catching objects, arrays
  if (msg !== null && typeof msg === 'object') {
    while (lvl-- && typeof argsCloned[0] === 'object') {
      Object.assign(o, argsCloned.shift())
    }
    msg = argsCloned.length ? format(argsCloned.shift(), argsCloned) : undefined
  } else if (typeof msg === 'string') msg = format(argsCloned.shift(), argsCloned)
  if (msg !== undefined) o.msg = msg
  return o
}

function applySerializers (args, serialize, serializers, stdErrSerialize) {
  for (const i in args) {
    if (stdErrSerialize && args[i] instanceof Error) {
      args[i] = pino.stdSerializers.err(args[i])
    } else if (typeof args[i] === 'object' && !Array.isArray(args[i])) {
      for (const k in args[i]) {
        if (serialize && serialize.indexOf(k) > -1 && k in serializers) {
          args[i][k] = serializers[k](args[i][k])
        }
      }
    }
  }
}

function transmit (logger, opts, args) {
  const send = opts.send
  const ts = opts.ts
  const methodLevel = opts.methodLevel
  const methodValue = opts.methodValue
  const val = opts.val
  const bindings = logger._logEvent.bindings

  applySerializers(
    args,
    logger._serialize || Object.keys(logger.serializers),
    logger.serializers,
    logger._stdErrSerialize === undefined ? true : logger._stdErrSerialize
  )
  logger._logEvent.ts = ts
  logger._logEvent.messages = args.filter(function (arg) {
    // bindings can only be objects, so reference equality check via indexOf is fine
    return bindings.indexOf(arg) === -1
  })

  logger._logEvent.level.label = methodLevel
  logger._logEvent.level.value = methodValue

  send(methodLevel, logger._logEvent, val)

  logger._logEvent = createLogEventShape(bindings)
}

function createLogEventShape (bindings) {
  return {
    ts: 0,
    messages: [],
    bindings: bindings || [],
    level: { label: '', value: 0 }
  }
}

function asErrValue (err) {
  const obj = {
    type: err.constructor.name,
    msg: err.message,
    stack: err.stack
  }
  for (const key in err) {
    if (obj[key] === undefined) {
      obj[key] = err[key]
    }
  }
  return obj
}

function getTimeFunction (opts) {
  if (typeof opts.timestamp === 'function') {
    return opts.timestamp
  }
  if (opts.timestamp === false) {
    return nullTime
  }
  return epochTime
}

function mock () { return {} }
function passthrough (a) { return a }
function noop () {}

function nullTime () { return false }
function epochTime () { return Date.now() }
function unixTime () { return Math.round(Date.now() / 1000.0) }
function isoTime () { return new Date(Date.now()).toISOString() } // using Date.now() for testability

/* eslint-disable */
/* istanbul ignore next */
function pfGlobalThisOrFallback () {
  function defd (o) { return typeof o !== 'undefined' && o }
  try {
    if (typeof globalThis !== 'undefined') return globalThis
    Object.defineProperty(Object.prototype, 'globalThis', {
      get: function () {
        delete Object.prototype.globalThis
        return (this.globalThis = this)
      },
      configurable: true
    })
    return globalThis
  } catch (e) {
    return defd(self) || defd(window) || defd(this) || {}
  }
}
/* eslint-enable */

module.exports["default"] = pino
module.exports.pino = pino


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {

;// CONCATENATED MODULE: ./src/shared/regexHelpers.ts
const validURLRegex = /https?:\/\/((www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b|localhost(:\d+)?)/gi;
const loginPageRegex = /\/login\/index.php/gi;
const dashboardPageRegex = /\/my/gi;
const coursePageRegex = /\/course\/(view|section)\.php\?id=[0-9]*/gi;
const courseResourcesPageRegex = /\/course\/resources\.php\?id=[0-9]*/gi;
const assignmentPageRegex = /\/mod\/assign\/view\.php\?(?=[^#]*\bid=[0-9]+)[^#]*/gi;
const videoServicePageRegex = /\/mod\/videoservice\/view\.php/gi;
const fileRegex = /\/mod\/resource\/view\.php\?id=[0-9]*/gi;
const folderRegex = /\/mod\/folder\/view\.php\?id=[0-9]*/gi;
const pluginFileRegex = /\/pluginfile\.php([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
const urlRegex = /\/mod\/url\/view\.php\?id=[0-9]*/gi;
const activityRegex = /\/mod\/(?!resource|folder)[A-z]*\/.*\.php.*/gi;
const allRegexes = {
    login: loginPageRegex,
    dashboard: dashboardPageRegex,
    course: coursePageRegex,
    courseResources: courseResourcesPageRegex,
    assignment: assignmentPageRegex,
    videoservice: videoServicePageRegex,
    file: fileRegex,
    folder: folderRegex,
    pluginfile: pluginFileRegex,
    url: urlRegex,
    activity: activityRegex,
};
function getURLRegex(type) {
    const baseUrlRegex = validURLRegex.source;
    const typeSpecificRegex = allRegexes[type].source;
    const regex = `${baseUrlRegex}.*${typeSpecificRegex}`;
    return new RegExp(regex, "gi");
}
function getMoodleBaseURL(string) {
    for (const regex of Object.values(allRegexes)) {
        const baseURLRegex = new RegExp(`.*(?=${regex.source})`);
        const match = string.match(baseURLRegex);
        if (match) {
            return match[0];
        }
    }
    return "";
}

// EXTERNAL MODULE: ./node_modules/pino/browser.js
var browser = __webpack_require__(4874);
var browser_default = /*#__PURE__*/__webpack_require__.n(browser);
;// CONCATENATED MODULE: ./src/shared/constants.ts
const constants_COMMANDS = {
    GET_STATE: "GET_STATE",
    STATE: "STATE",
    EVENT: "EVENT",
    PAGE_DATA: "PAGE_DATA",
    FEEDBACK: "FEEDBACK",
    SET_BADGE: "SET_BADGE",
    SET_ICON: "SET_ICON",
    ERROR_VIEW: "ERROR_VIEW",
    LOG: "LOG",
    EXECUTE_SCRIPT: "EXECUTE_SCRIPT",
    COURSE_CRAWL: "COURSE_CRAWL",
    DASHBOARD_DOWNLOAD_NEW: "DASHBOARD_DOWNLOAD_NEW",
    SCAN_IN_PROGRESS: "SCAN_IN_PROGRESS",
    INIT_SCAN: "INIT_SCAN",
    SCAN_RESULT: "SCAN_RESULT",
    MARK_AS_SEEN: "MARK_AS_SEEN",
    CANCEL_DOWNLOAD: "CANCEL_DOWNLOAD",
    UPDATE_ACTIVITIES: "UPDATE_ACTIVITIES",
    DOWNLOAD: "DOWNLOAD",
    DOWNLOAD_PROGRESS: "DOWNLOAD_PROGRESS",
    VIDEO_DOWNLOAD_PROGRESS: "VIDEO_DOWNLOAD_PROGRESS",
    CLEAR_COURSE_DATA: "CLEAR_COURSE_DATA",
    RATE_CLICK: "RATE_CLICK",
    AVOID_RATE_CLICK: "AVOID_RATE_CLICK",
    CLEAR_COURSE: "CLEAR_COURSE",
    TRACK_PAGE_VIEW: "TRACK_PAGE_VIEW",
    ENSURE_CORRECT_BADGE: "ENSURE_CORRECT_BADGE",
    BACKGROUND_SCAN: "BACKGROUND_SCAN",
    CHECK_BACKGROUND_SCAN: "CHECK_BACKGROUND_SCAN",
    RESET_STORAGE: "RESET_STORAGE",
    BG_COURSE_SCAN: "BG_COURSE_SCAN",
    BG_COURSE_SCAN_RESULT: "BG_COURSE_SCAN_RESULT",
    DEV_CLEAR_SEEN_RESOURCES: "DEV_CLEAR_SEEN_RESOURCES",
    DOWNLOAD_ALL: "DOWNLOAD_ALL",
    DASHBOARD_DOWNLOAD_COURSE: "DASHBOARD_DOWNLOAD_COURSE",
    DASHBOARD_UPDATE_COURSE: "DASHBOARD_UPDATE_COURSE",
    GET_DOWNLOAD_STATE: "GET_DOWNLOAD_STATE",
};

;// CONCATENATED MODULE: ./node_modules/detect-browser/es/index.js
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var BrowserInfo = /** @class */ (function () {
    function BrowserInfo(name, version, os) {
        this.name = name;
        this.version = version;
        this.os = os;
        this.type = 'browser';
    }
    return BrowserInfo;
}());

var NodeInfo = /** @class */ (function () {
    function NodeInfo(version) {
        this.version = version;
        this.type = 'node';
        this.name = 'node';
        this.os = process.platform;
    }
    return NodeInfo;
}());

var SearchBotDeviceInfo = /** @class */ (function () {
    function SearchBotDeviceInfo(name, version, os, bot) {
        this.name = name;
        this.version = version;
        this.os = os;
        this.bot = bot;
        this.type = 'bot-device';
    }
    return SearchBotDeviceInfo;
}());

var BotInfo = /** @class */ (function () {
    function BotInfo() {
        this.type = 'bot';
        this.bot = true; // NOTE: deprecated test name instead
        this.name = 'bot';
        this.version = null;
        this.os = null;
    }
    return BotInfo;
}());

var ReactNativeInfo = /** @class */ (function () {
    function ReactNativeInfo() {
        this.type = 'react-native';
        this.name = 'react-native';
        this.version = null;
        this.os = null;
    }
    return ReactNativeInfo;
}());

// tslint:disable-next-line:max-line-length
var SEARCHBOX_UA_REGEX = /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/;
var SEARCHBOT_OS_REGEX = /(nuhk|curl|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/;
var REQUIRED_VERSION_PARTS = 3;
var userAgentRules = [
    ['aol', /AOLShield\/([0-9\._]+)/],
    ['edge', /Edge\/([0-9\._]+)/],
    ['edge-ios', /EdgiOS\/([0-9\._]+)/],
    ['yandexbrowser', /YaBrowser\/([0-9\._]+)/],
    ['kakaotalk', /KAKAOTALK\s([0-9\.]+)/],
    ['samsung', /SamsungBrowser\/([0-9\.]+)/],
    ['silk', /\bSilk\/([0-9._-]+)\b/],
    ['miui', /MiuiBrowser\/([0-9\.]+)$/],
    ['beaker', /BeakerBrowser\/([0-9\.]+)/],
    ['edge-chromium', /EdgA?\/([0-9\.]+)/],
    [
        'chromium-webview',
        /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/,
    ],
    ['chrome', /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
    ['phantomjs', /PhantomJS\/([0-9\.]+)(:?\s|$)/],
    ['crios', /CriOS\/([0-9\.]+)(:?\s|$)/],
    ['firefox', /Firefox\/([0-9\.]+)(?:\s|$)/],
    ['fxios', /FxiOS\/([0-9\.]+)/],
    ['opera-mini', /Opera Mini.*Version\/([0-9\.]+)/],
    ['opera', /Opera\/([0-9\.]+)(?:\s|$)/],
    ['opera', /OPR\/([0-9\.]+)(:?\s|$)/],
    ['pie', /^Microsoft Pocket Internet Explorer\/(\d+\.\d+)$/],
    ['pie', /^Mozilla\/\d\.\d+\s\(compatible;\s(?:MSP?IE|MSInternet Explorer) (\d+\.\d+);.*Windows CE.*\)$/],
    ['netfront', /^Mozilla\/\d\.\d+.*NetFront\/(\d.\d)/],
    ['ie', /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
    ['ie', /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
    ['ie', /MSIE\s(7\.0)/],
    ['bb10', /BB10;\sTouch.*Version\/([0-9\.]+)/],
    ['android', /Android\s([0-9\.]+)/],
    ['ios', /Version\/([0-9\._]+).*Mobile.*Safari.*/],
    ['safari', /Version\/([0-9\._]+).*Safari/],
    ['facebook', /FB[AS]V\/([0-9\.]+)/],
    ['instagram', /Instagram\s([0-9\.]+)/],
    ['ios-webview', /AppleWebKit\/([0-9\.]+).*Mobile/],
    ['ios-webview', /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
    ['curl', /^curl\/([0-9\.]+)$/],
    ['searchbot', SEARCHBOX_UA_REGEX],
];
var operatingSystemRules = (/* unused pure expression or super */ null && ([
    ['iOS', /iP(hone|od|ad)/],
    ['Android OS', /Android/],
    ['BlackBerry OS', /BlackBerry|BB10/],
    ['Windows Mobile', /IEMobile/],
    ['Amazon OS', /Kindle/],
    ['Windows 3.11', /Win16/],
    ['Windows 95', /(Windows 95)|(Win95)|(Windows_95)/],
    ['Windows 98', /(Windows 98)|(Win98)/],
    ['Windows 2000', /(Windows NT 5.0)|(Windows 2000)/],
    ['Windows XP', /(Windows NT 5.1)|(Windows XP)/],
    ['Windows Server 2003', /(Windows NT 5.2)/],
    ['Windows Vista', /(Windows NT 6.0)/],
    ['Windows 7', /(Windows NT 6.1)/],
    ['Windows 8', /(Windows NT 6.2)/],
    ['Windows 8.1', /(Windows NT 6.3)/],
    ['Windows 10', /(Windows NT 10.0)/],
    ['Windows ME', /Windows ME/],
    ['Windows CE', /Windows CE|WinCE|Microsoft Pocket Internet Explorer/],
    ['Open BSD', /OpenBSD/],
    ['Sun OS', /SunOS/],
    ['Chrome OS', /CrOS/],
    ['Linux', /(Linux)|(X11)/],
    ['Mac OS', /(Mac_PowerPC)|(Macintosh)/],
    ['QNX', /QNX/],
    ['BeOS', /BeOS/],
    ['OS/2', /OS\/2/],
]));
function detect(userAgent) {
    if (!!userAgent) {
        return parseUserAgent(userAgent);
    }
    if (typeof document === 'undefined' &&
        typeof navigator !== 'undefined' &&
        navigator.product === 'ReactNative') {
        return new ReactNativeInfo();
    }
    if (typeof navigator !== 'undefined') {
        return parseUserAgent(navigator.userAgent);
    }
    return getNodeVersion();
}
function matchUserAgent(ua) {
    // opted for using reduce here rather than Array#first with a regex.test call
    // this is primarily because using the reduce we only perform the regex
    // execution once rather than once for the test and for the exec again below
    // probably something that needs to be benchmarked though
    return (ua !== '' &&
        userAgentRules.reduce(function (matched, _a) {
            var browser = _a[0], regex = _a[1];
            if (matched) {
                return matched;
            }
            var uaMatch = regex.exec(ua);
            return !!uaMatch && [browser, uaMatch];
        }, false));
}
function browserName(ua) {
    var data = matchUserAgent(ua);
    return data ? data[0] : null;
}
function parseUserAgent(ua) {
    var matchedRule = matchUserAgent(ua);
    if (!matchedRule) {
        return null;
    }
    var name = matchedRule[0], match = matchedRule[1];
    if (name === 'searchbot') {
        return new BotInfo();
    }
    // Do not use RegExp for split operation as some browser do not support it (See: http://blog.stevenlevithan.com/archives/cross-browser-split)
    var versionParts = match[1] && match[1].split('.').join('_').split('_').slice(0, 3);
    if (versionParts) {
        if (versionParts.length < REQUIRED_VERSION_PARTS) {
            versionParts = __spreadArray(__spreadArray([], versionParts, true), createVersionParts(REQUIRED_VERSION_PARTS - versionParts.length), true);
        }
    }
    else {
        versionParts = [];
    }
    var version = versionParts.join('.');
    var os = detectOS(ua);
    var searchBotMatch = SEARCHBOT_OS_REGEX.exec(ua);
    if (searchBotMatch && searchBotMatch[1]) {
        return new SearchBotDeviceInfo(name, version, os, searchBotMatch[1]);
    }
    return new BrowserInfo(name, version, os);
}
function detectOS(ua) {
    for (var ii = 0, count = operatingSystemRules.length; ii < count; ii++) {
        var _a = operatingSystemRules[ii], os = _a[0], regex = _a[1];
        var match = regex.exec(ua);
        if (match) {
            return os;
        }
    }
    return null;
}
function getNodeVersion() {
    var isNode = typeof process !== 'undefined' && process.version;
    return isNode ? new NodeInfo(process.version.slice(1)) : null;
}
function createVersionParts(count) {
    var output = [];
    for (var ii = 0; ii < count; ii++) {
        output.push('0');
    }
    return output;
}

;// CONCATENATED MODULE: ./src/shared/helpers.ts


const isDev = "production" !== "production";
const isDebug = (/* unused pure expression or super */ null && ("production" === "debug"));
function sendEvent(event, saveURL = true, eventData = {}) {
    chrome.runtime.sendMessage({
        command: COMMANDS.EVENT,
        event,
        saveURL,
        eventData,
    });
}
function sendLog(logData) {
    chrome.runtime.sendMessage({
        command: constants_COMMANDS.LOG,
        logData,
    });
    if (logData.page) {
        sendPageData(logData.page);
    }
}
function sendPageData(page) {
    const pageData = {
        page,
        content: document.querySelector("html")?.outerHTML || "",
    };
    chrome.runtime.sendMessage({
        command: constants_COMMANDS.PAGE_DATA,
        pageData,
    });
}
async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs?.shift();
}
const isFirefox = browserName(navigator?.userAgent) === "firefox";
function getUpdatesFromCourses(courses) {
    const courseList = courses.flat();
    const nUpdates = courseList.reduce((sum, c) => {
        const nUpdatesInCourse = [...c.resources, ...c.activities].filter((r) => r.isNew || r.isUpdated).length;
        return sum + nUpdatesInCourse;
    }, 0);
    return nUpdates;
}
async function updateIconFromCourses(courses) {
    const nUpdates = getUpdatesFromCourses(courses);
    await chrome.storage.local.set({ nUpdates });
    const text = nUpdates === 0 ? "" : nUpdates.toString();
    chrome.runtime.sendMessage({
        command: constants_COMMANDS.SET_BADGE,
        text,
        global: false,
    });
}
function getCourseDownloadId(command, course) {
    return `${command}_${course.link}`;
}

;// CONCATENATED MODULE: ./src/shared/logger.ts


/* harmony default export */ const logger = (browser_default()({
    level: isDev ? "debug" : "info",
}));

;// CONCATENATED MODULE: ./src/shared/parser.ts


function checkForMoodle() {
    const isMoodle = Boolean(document.querySelector("#region-main"));
    logger.debug({ isMoodle });
    return isMoodle;
}
function isTilesFormat(document) {
    return Boolean(document.querySelector("#format-tiles-multi-section-page"));
}
function parseCourseShortcut(document, options) {
    if (options.customSelectorCourseShortcut) {
        const customSelectorResult = document.querySelector(options.customSelectorCourseShortcut);
        if (customSelectorResult) {
            const textContent = customSelectorResult?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    const shortcutNode = document.querySelector("a[aria-current='page']");
    if (shortcutNode) {
        const textContent = shortcutNode?.textContent?.trim();
        if (textContent) {
            return textContent;
        }
    }
    const possibleNavbarContainers = document.querySelectorAll("#page, #page-header, #page-navbar");
    if (possibleNavbarContainers) {
        for (const container of Array.from(possibleNavbarContainers)) {
            const navbar = container.querySelector("nav, ol, ul");
            if (navbar) {
                const allNavElements = Array.from(navbar.querySelectorAll("li"));
                const lastNav = allNavElements.pop();
                if (lastNav) {
                    const textContent = lastNav?.textContent?.trim();
                    if (textContent) {
                        return textContent;
                    }
                }
            }
        }
    }
    return "Unknown Shortcut";
}
function parseCourseNameFromCoursePage(document, options) {
    if (options.customSelectorCourseName) {
        const customSelectorResult = document.querySelector(options.customSelectorCourseName);
        if (customSelectorResult) {
            const textContent = customSelectorResult?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    const header = document.querySelector(".page-header-headings");
    if (header && header.children.length > 0) {
        const textContent = header.children[0]?.textContent?.trim();
        if (textContent) {
            return textContent;
        }
    }
    const shortcutNode = document.querySelector("a[aria-current='page']");
    if (shortcutNode) {
        const title = shortcutNode?.title?.trim();
        if (title) {
            return title;
        }
        const textContent = shortcutNode?.textContent?.trim();
        if (textContent) {
            return textContent;
        }
    }
    const mainHTML = document.querySelector("#region-main");
    if (mainHTML) {
        const firstHeader = mainHTML.querySelector("h1");
        if (firstHeader) {
            const textContent = firstHeader?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    const possibleTitleContainers = document.querySelectorAll("#page, #page-header, #page-navbar");
    if (possibleTitleContainers) {
        for (const container of Array.from(possibleTitleContainers)) {
            const titleElement = container.querySelector("h1");
            if (titleElement) {
                const textContent = titleElement?.textContent?.trim();
                if (textContent) {
                    return textContent;
                }
            }
        }
    }
    const shortcut = parseCourseShortcut(document, options);
    if (shortcut !== "" && shortcut !== "Unknown Shortcut") {
        return shortcut;
    }
    return "Unknown Course";
}
function parseCourseLink(htmlString) {
    const courseURLRegex = getURLRegex("course");
    const match = htmlString.match(courseURLRegex);
    return match ? match[0] : htmlString;
}
const ASSIGNMENT_NAME_SELECTORS = [
    ".page-header-headings h1", "#page-header h1", ".page-context-header h1",
    "#region-main h2", "#region-main h1", "h1",
];
function parseAssignmentNameFromPage(document) {
    for (const sel of ASSIGNMENT_NAME_SELECTORS) {
        const text = document.querySelector(sel)?.textContent?.replace(/\s+/g, " ")?.trim();
        if (text)
            return text;
    }
    return "";
}
function getBreadcrumbItems(document) {
    const breadcrumb = document.querySelector(".breadcrumb, nav[aria-label] ol, [role='navigation'] ol");
    return breadcrumb ? Array.from(breadcrumb.querySelectorAll("li")) : [];
}
function breadcrumbText(item) {
    return item?.textContent?.replace(/[\/]/g, "")?.replace(/\s+/g, " ")?.trim() || "";
}
function parseCourseNameFromBreadcrumb(document) {
    const items = getBreadcrumbItems(document);
    const courseURLRegex = getURLRegex("course");
    const idx = items.findIndex((item) => item.querySelector("a")?.href.match(courseURLRegex));
    return idx !== -1 ? breadcrumbText(items[idx]) : "";
}
function parseSectionFromBreadcrumb(document) {
    const items = getBreadcrumbItems(document);
    const courseURLRegex = getURLRegex("course");
    const idx = items.findIndex((item) => item.querySelector("a")?.href.match(courseURLRegex));
    if (idx !== -1 && idx < items.length - 2)
        return breadcrumbText(items[idx + 1]);
    return "";
}
function getQuerySelector(type, options) {
    const baseURL = "";
    const fileSelector = `[href*="${baseURL}/mod/resource"]`;
    const folderSelector = `[href*="${baseURL}/mod/folder"]`;
    const pluginFileSelector = `[href*="${baseURL}/pluginfile"]:not(.mediafallbacklink)`;
    const urlSelector = `[href*="${baseURL}/mod/url"]`;
    const videoSelector = `video source`;
    const audioSelector = `audio source`;
    const imageSelector = `img[src*="${baseURL}/pluginfile"]`;
    const videoServiceSelector = `video[src*="${baseURL}/mod/videoservice/file.php"]`;
    const activityQuerySelector = `[href*="${baseURL}/mod/"]:not(${fileSelector}):not(${folderSelector})`;
    let selector = "";
    switch (type) {
        case "file":
            selector = fileSelector;
            break;
        case "folder":
            selector = folderSelector;
            break;
        case "pluginfile":
            selector = pluginFileSelector;
            break;
        case "url":
            selector = urlSelector;
            break;
        case "activity":
            selector = activityQuerySelector;
            break;
        case "video":
            selector = videoSelector;
            break;
        case "audio":
            selector = audioSelector;
            break;
        case "image":
            selector = imageSelector;
            break;
        case "media":
            const mediaSelectors = [];
            if (options.includeVideo) {
                mediaSelectors.push(videoSelector);
            }
            if (options.includeAudio) {
                mediaSelectors.push(audioSelector);
            }
            if (options.includeImage) {
                mediaSelectors.push(imageSelector);
            }
            selector = mediaSelectors.join(",") || "pleasedontmatchanything";
            break;
        case "videoservice":
            selector = videoServiceSelector;
            break;
        default:
            break;
    }
    selector = `${selector}:not(.helplinkpopup)`;
    return selector;
}
function parseURLFromNode(node, type, options) {
    const aTag = node.querySelector(getQuerySelector(type, options));
    if (aTag) {
        return aTag.href;
    }
    if (node.tagName === "A") {
        return node.href;
    }
    if (type === "pluginfile") {
        const mediaTag = node.querySelector(getQuerySelector("media", options));
        const mediaTags = ["IMG", "VIDEO", "AUDIO"];
        if (mediaTags.includes(mediaTag?.tagName ?? "")) {
            return mediaTag.src;
        }
        if (mediaTags.includes(node?.tagName ?? "")) {
            return node.src;
        }
    }
    if (node.tagName === "SOURCE") {
        return node.src;
    }
    return "";
}
function parseFileNameFromNode(node) {
    let contentNode = node.querySelector(".instancename");
    if (contentNode) {
        const { firstChild } = contentNode;
        if (firstChild) {
            const textContent = firstChild?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    contentNode = node.querySelector(".fp-filename");
    if (contentNode) {
        const textContent = contentNode?.textContent?.trim();
        if (textContent) {
            return textContent;
        }
    }
    const textContent = node?.textContent?.trim();
    if (textContent) {
        return textContent;
    }
    return "Unknown Filename";
}
function parseFileNameFromPluginFileURL(url) {
    let fileName = "";
    const urlParts = url.split("/");
    const lastUrlPart = urlParts.pop();
    if (lastUrlPart) {
        const [path] = lastUrlPart.split(/[#?]/);
        fileName = path;
    }
    fileName = decodeURIComponent(fileName);
    const specialCharacters = {
        "%21": "!",
        "%23": "#",
        "%24": "$",
        "%25": "%",
        "%26": "&",
        "%27": "'",
        "%28": "(",
        "%29": ")",
        "%2A": "*",
        "%2B": "+",
        "%2C": ",",
        "%2F": "/",
        "%3A": ":",
        "%3B": ";",
        "%3D": "=",
        "%3F": "?",
        "%40": "@",
        "%5B": "[",
        "%5D": "]",
    };
    for (const percentChar of Object.keys(specialCharacters)) {
        fileName = fileName.replace(percentChar, specialCharacters[percentChar]);
    }
    return fileName;
}
function parseActivityNameFromNode(node) {
    const contentNode = node.querySelector(".instancename");
    if (contentNode) {
        const { firstChild } = contentNode;
        if (firstChild) {
            const textContent = firstChild?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    return "Unknown Activity";
}
function parseActivityTypeFromNode(node) {
    const modtypeClass = Array.from(node.classList).find((className) => className.startsWith("modtype_"));
    if (modtypeClass) {
        const activityType = modtypeClass.replace(/^modtype_/, "").trim();
        if (activityType) {
            return activityType;
        }
    }
    const contentNode = node.querySelector(".accesshide");
    if (contentNode) {
        const { firstChild } = contentNode;
        if (firstChild) {
            const textContent = firstChild?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    return "Unkown Activity Type";
}
function parseSectionName(node, document, options) {
    const sectionSelector = options.customSelectorSectionElement || "[id^='section-']";
    const section = node.closest(sectionSelector);
    if (!section) {
        return "";
    }
    if (options.customSelectorSectionName) {
        const customSelectorResult = section.querySelector(options.customSelectorSectionName);
        if (customSelectorResult) {
            const textContent = customSelectorResult?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    const ariaLabel = section.attributes.getNamedItem("aria-label")?.value?.trim();
    if (ariaLabel) {
        return ariaLabel;
    }
    const ariaLabelledBy = section.attributes.getNamedItem("aria-labelledby");
    if (ariaLabelledBy) {
        const label = document.getElementById(ariaLabelledBy.value);
        if (label) {
            const textContent = label?.textContent?.trim();
            if (textContent) {
                return textContent;
            }
        }
    }
    const sectionNameElement = section.querySelector(".sectionname");
    if (sectionNameElement) {
        const textContent = sectionNameElement?.textContent?.trim();
        if (textContent) {
            return textContent;
        }
    }
    const tileText = section.querySelector("h3")?.textContent?.trim();
    if (tileText)
        return tileText;
    if (section.id === "section-0") {
        return "";
    }
    return "Unknown Section";
}
function getDownloadButton(node) {
    return node.querySelector(`form[action$="/mod/folder/download_folder.php"]`);
}
function getDownloadIdTag(node) {
    return node.querySelector("input[name='id']");
}

;// CONCATENATED MODULE: ./src/models/Course.ts



async function getLastModifiedHeader(href, options) {
    if (!options.detectFileUpdates)
        return;
    const headResponse = await fetch(href, {
        method: "HEAD",
    });
    const lastModified = headResponse.headers.get("last-modified");
    return lastModified ?? undefined;
}
const courseURLRegex = getURLRegex("course");
const assignmentURLRegex = getURLRegex("assignment");
class Course {
    link;
    HTMLDocument;
    name;
    shortcut;
    isFirstScan;
    isCoursePage;
    options;
    resources;
    previousSeenResources;
    activities;
    previousSeenActivities;
    lastModifiedHeaders;
    sectionIndices;
    constructor(link, HTMLDocument, options) {
        this.link = link;
        this.HTMLDocument = HTMLDocument;
        this.options = options;
        this.name = parseCourseNameFromCoursePage(HTMLDocument, options);
        this.shortcut = parseCourseShortcut(HTMLDocument, options);
        this.isFirstScan = true;
        this.isCoursePage = !!link.match(courseURLRegex);
        this.resources = [];
        this.previousSeenResources = null;
        this.activities = [];
        this.previousSeenActivities = null;
        this.sectionIndices = {};
    }
    getSectionIndex(section) {
        if (this.sectionIndices[section] === undefined) {
            this.sectionIndices[section] = Object.keys(this.sectionIndices).length;
        }
        return this.sectionIndices[section] + 1;
    }
    createCourseDataSnapshot() {
        const lastModifiedHeaders = this.lastModifiedHeaders ?? Object.fromEntries(this.resources.map((r) => [r.href, r.lastModified]));
        return {
            seenResources: this.resources.filter((resource) => !resource.isNew).map((resource) => resource.href),
            newResources: this.resources.filter((resource) => resource.isNew).map((resource) => resource.href),
            seenActivities: this.activities.filter((activity) => !activity.isNew).map((activity) => activity.href),
            newActivities: this.activities.filter((activity) => activity.isNew).map((activity) => activity.href),
            lastModifiedHeaders,
        };
    }
    addResource(resource) {
        if (this.previousSeenResources !== null) {
            const hasNotBeenSeenBefore = !this.previousSeenResources.includes(resource.href);
            if (hasNotBeenSeenBefore) {
                resource.isNew = true;
                logger.debug(resource, "New resource detected");
            }
            if (this.options.detectFileUpdates) {
                const hasBeenUpdated = (this.lastModifiedHeaders ?? {})[resource.href] !== resource.lastModified;
                if (!resource.isNew && hasBeenUpdated) {
                    resource.isUpdated = true;
                }
            }
        }
        else {
            resource.isNew = false;
            resource.isUpdated = false;
        }
        this.resources.push(resource);
    }
    async addFile(node) {
        const href = parseURLFromNode(node, "file", this.options);
        if (href === "")
            return;
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        const sectionIndex = this.getSectionIndex(section);
        const resource = {
            href,
            name: parseFileNameFromNode(node),
            section,
            type: "file",
            isNew: false,
            isUpdated: false,
            resourceIndex: this.resources.length + 1,
            sectionIndex,
            lastModified: await getLastModifiedHeader(href, this.options),
        };
        this.addResource(resource);
    }
    async addPluginFile(node, partOfFolder = "") {
        let href = parseURLFromNode(node, "pluginfile", this.options);
        if (href === "")
            return;
        const detectedURLs = this.resources.map((r) => r.href);
        if (detectedURLs.includes(href))
            return;
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        const sectionIndex = this.getSectionIndex(section);
        const resource = {
            href,
            name: parseFileNameFromPluginFileURL(href),
            section,
            type: "pluginfile",
            partOfFolder,
            isNew: false,
            isUpdated: false,
            resourceIndex: this.resources.length + 1,
            sectionIndex,
            lastModified: await getLastModifiedHeader(href, this.options),
        };
        this.addResource(resource);
    }
    async addURLNode(node) {
        const addedAsZoom = await this.addZoomRecordingFromURLNode(node);
        if (addedAsZoom)
            return;
        const activityIcon = node.querySelector("img.activityicon");
        if (activityIcon) {
            const imgName = activityIcon.src.split("/").pop();
            if (imgName) {
                const isFile = imgName !== "icon";
                if (isFile) {
                    const href = parseURLFromNode(node, "url", this.options);
                    if (href === "")
                        return;
                    const section = parseSectionName(node, this.HTMLDocument, this.options);
                    const sectionIndex = this.getSectionIndex(section);
                    const resourceNode = {
                        href,
                        name: parseFileNameFromNode(node),
                        section,
                        type: "url",
                        isNew: false,
                        isUpdated: false,
                        resourceIndex: this.resources.length + 1,
                        sectionIndex,
                        lastModified: await getLastModifiedHeader(href, this.options),
                    };
                    this.addResource(resourceNode);
                }
            }
        }
    }
    static ZOOM_RECORDING_REGEX = /https?:\/\/[^/]*zoom\.[^/]+\/rec\/(share|play)\//i;
    async addZoomRecordingFromURLNode(node) {
        const href = parseURLFromNode(node, "url", this.options);
        if (href === "")
            return false;
        try {
            const res = await fetch(href);
            const doc = new DOMParser().parseFromString(await res.text(), "text/html");
            const targetUrl = doc.querySelector(".urlworkaround a[href]")?.getAttribute("href") || "";
            if (!Course.ZOOM_RECORDING_REGEX.test(targetUrl))
                return false;
            const section = parseSectionName(node, this.HTMLDocument, this.options);
            const resource = {
                href,
                name: parseFileNameFromNode(node),
                section,
                type: "zoom",
                zoomUrl: targetUrl,
                isNew: false,
                isUpdated: false,
                resourceIndex: this.resources.length + 1,
                sectionIndex: this.getSectionIndex(section),
            };
            this.addResource(resource);
            return true;
        }
        catch (err) {
            logger.error("Failed to check URL node for Zoom recording", err);
            return false;
        }
    }
    async addFolder(node) {
        const href = parseURLFromNode(node, "folder", this.options);
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        const sectionIndex = this.getSectionIndex(section);
        const resource = {
            href,
            name: parseFileNameFromNode(node),
            section,
            type: "folder",
            isInline: false,
            isNew: false,
            isUpdated: false,
            resourceIndex: this.resources.length + 1,
            sectionIndex,
        };
        if (resource.href === "") {
            const downloadButtonVisible = getDownloadButton(node) !== null;
            const { downloadFolderAsZip } = this.options;
            if (downloadFolderAsZip && downloadButtonVisible) {
                const downloadIdTag = getDownloadIdTag(node);
                if (downloadIdTag === null)
                    return;
                const baseURL = getMoodleBaseURL(this.link);
                const downloadId = downloadIdTag.getAttribute("value");
                const downloadURL = `${baseURL}/mod/folder/download_folder.php?id=${downloadId}`;
                resource.href = downloadURL;
                resource.isInline = true;
            }
            else {
                const folderFiles = node.querySelectorAll(getQuerySelector("pluginfile", this.options));
                for (const pluginFile of Array.from(folderFiles)) {
                    await this.addPluginFile(pluginFile, resource.name);
                }
                return;
            }
        }
        if (resource.href !== "") {
            resource.lastModified = await getLastModifiedHeader(resource.href, this.options);
        }
        this.addResource(resource);
    }
    async addAssignmentResource(href, name, section) {
        this.addResource({
            href,
            name,
            section,
            type: "assignment",
            isNew: false,
            isUpdated: false,
            resourceIndex: this.resources.length + 1,
            sectionIndex: this.getSectionIndex(section),
            lastModified: await getLastModifiedHeader(href, this.options),
        });
    }
    async addAssignment(node) {
        const href = parseURLFromNode(node, "activity", this.options);
        if (href === "")
            return;
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        await this.addAssignmentResource(href, parseActivityNameFromNode(node), section);
    }
    async addCurrentAssignmentPage() {
        const courseName = parseCourseNameFromBreadcrumb(this.HTMLDocument);
        if (courseName)
            this.name = courseName;
        const section = parseSectionFromBreadcrumb(this.HTMLDocument);
        await this.addAssignmentResource(this.link, parseAssignmentNameFromPage(this.HTMLDocument), section);
    }
    async addEmbeddedVideo(node) {
        const href = parseURLFromNode(node, "activity", this.options);
        if (href === "")
            return;
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        const sectionIndex = this.getSectionIndex(section);
        const resource = {
            href,
            name: parseFileNameFromNode(node),
            section,
            type: "embedded-video",
            isNew: false,
            isUpdated: false,
            resourceIndex: this.resources.length + 1,
            sectionIndex,
        };
        this.addResource(resource);
    }
    addSidebarVideos() {
        const sidebarVideoLinks = this.HTMLDocument.querySelectorAll('a[href*="/blocks/video/viewvideo"]');
        for (const link of Array.from(sidebarVideoLinks)) {
            const href = link.href;
            if (!href)
                continue;
            if (this.resources.some((r) => r.href === href))
                continue;
            let name = link.textContent?.trim() || "";
            if (!name) {
                const parent = link.closest("[class]")?.parentElement;
                if (parent) {
                    const textLink = parent.querySelector('a[href*="/blocks/video/viewvideo"]:not(:has(img))');
                    name = textLink?.textContent?.trim() || "";
                }
            }
            if (!name)
                continue;
            const resource = {
                href,
                name,
                section: "Sidebar Videos",
                type: "sidebar-video",
                isNew: false,
                isUpdated: false,
                resourceIndex: this.resources.length + 1,
                sectionIndex: this.getSectionIndex("Sidebar Videos"),
            };
            this.addResource(resource);
        }
    }
    async addActivity(node) {
        if (!this.isCoursePage) {
            return;
        }
        const activityType = parseActivityTypeFromNode(node);
        if (activityType === "assign") {
            await this.addAssignment(node);
            return;
        }
        if (activityType === "videostream") {
            await this.addEmbeddedVideo(node);
            return;
        }
        const section = parseSectionName(node, this.HTMLDocument, this.options);
        const sectionIndex = this.getSectionIndex(section);
        const href = parseURLFromNode(node, "activity", this.options);
        if (href === "")
            return;
        const activity = {
            href,
            name: parseActivityNameFromNode(node),
            section: parseSectionName(node, this.HTMLDocument, this.options),
            isNew: false,
            isUpdated: false,
            type: "activity",
            activityType,
            resourceIndex: this.activities.length + 1,
            sectionIndex,
        };
        if (this.previousSeenActivities !== null &&
            !this.previousSeenActivities.includes(activity.href)) {
            activity.isNew = true;
        }
        this.activities.push(activity);
    }
    async scan(testLocalStorage) {
        this.resources = [];
        this.previousSeenResources = null;
        this.activities = [];
        this.previousSeenActivities = null;
        this.sectionIndices = {};
        const localStorage = testLocalStorage ?? (await chrome.storage.local.get());
        const { options, courseData } = localStorage;
        this.options = options;
        if (courseData[this.link]) {
            this.isFirstScan = false;
            const storedCourseData = courseData[this.link];
            logger.debug(storedCourseData, "Course was found in local storage");
            this.previousSeenResources = storedCourseData.seenResources;
            this.previousSeenActivities = storedCourseData.seenActivities;
            this.lastModifiedHeaders = storedCourseData.lastModifiedHeaders;
        }
        else {
            logger.debug(`New course detected ${this.name}`);
        }
        const mainHTML = this.HTMLDocument.querySelector("#region-main");
        if (!mainHTML) {
            return;
        }
        if (this.link.match(assignmentURLRegex)) {
            await this.addCurrentAssignmentPage();
            logger.debug("Assignment page scan finished", { course: this });
        }
        else {
            if (isTilesFormat(this.HTMLDocument)) {
                await this.processTiles(mainHTML);
            }
            const modules = mainHTML.querySelectorAll("li[id^='module-']");
            if (modules && modules.length !== 0) {
                for (const node of Array.from(modules)) {
                    const isFile = node.classList.contains("resource");
                    const isFolder = node.classList.contains("folder");
                    const isURL = node.classList.contains("url");
                    if (isFile) {
                        await this.addFile(node);
                    }
                    else if (isFolder) {
                        await this.addFolder(node);
                    }
                    else if (isURL) {
                        await this.addURLNode(node);
                    }
                    else {
                        await this.addActivity(node);
                    }
                }
                const pluginFileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("pluginfile", this.options)));
                const mediaFileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("media", this.options)));
                await Promise.all(pluginFileNodes.map((n) => this.addPluginFile(n)));
                await Promise.all(mediaFileNodes.map((n) => this.addPluginFile(n)));
            }
            else {
                const fileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("file", this.options)));
                const pluginFileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("pluginfile", this.options)));
                const urlFileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("url", this.options)));
                const mediaFileNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("media", this.options)));
                const folderNodes = Array.from(mainHTML.querySelectorAll(getQuerySelector("folder", this.options)));
                const activities = Array.from(mainHTML.querySelectorAll(getQuerySelector("activity", this.options)));
                await Promise.all(fileNodes.map((n) => this.addFile(n)));
                await Promise.all(pluginFileNodes.map((n) => this.addPluginFile(n)));
                await Promise.all(urlFileNodes.map((n) => this.addURLNode(n)));
                await Promise.all(mediaFileNodes.map((n) => this.addPluginFile(n)));
                await Promise.all(folderNodes.map((n) => this.addFolder(n)));
                await Promise.all(activities.map((n) => this.addActivity(n)));
            }
            logger.debug("Course scan finished", { course: this });
        }
        this.addSidebarVideos();
        if (testLocalStorage) {
            return;
        }
        const uniqueResourcesMap = new Map();
        for (const res of this.resources) {
            if (!uniqueResourcesMap.has(res.href)) {
                uniqueResourcesMap.set(res.href, res);
            }
        }
        this.resources = Array.from(uniqueResourcesMap.values());
        if (this.lastModifiedHeaders === undefined) {
            this.lastModifiedHeaders = Object.fromEntries(this.resources.map((r) => [r.href, r.lastModified]));
        }
        const updatedCourseData = this.createCourseDataSnapshot();
        courseData[this.link] = updatedCourseData;
        logger.debug(`Storing course data in local storage for course ${this.name}`, {
            updatedCourseData,
        });
        await chrome.storage.local.set({ courseData });
    }
    async updateStoredResources(downloadedResources) {
        const { courseData } = (await chrome.storage.local.get("courseData"));
        const storedCourseData = courseData[this.link] ?? this.createCourseDataSnapshot();
        const { seenResources, lastModifiedHeaders } = storedCourseData;
        const newResources = this.resources.filter((n) => n.isNew);
        let toBeMerged = newResources;
        if (downloadedResources) {
            toBeMerged = downloadedResources;
        }
        logger.debug(toBeMerged, "Adding resources to list of seen resources");
        const updatedSeenResources = Array.from(new Set(seenResources.concat(toBeMerged.map((r) => r.href))));
        const updatedNewResources = newResources
            .filter((r) => !updatedSeenResources.includes(r.href))
            .map((r) => r.href);
        if (lastModifiedHeaders) {
            const toBeUpdated = toBeMerged;
            if (downloadedResources === undefined) {
                const updatedResources = this.resources.filter((n) => n.isUpdated);
                toBeUpdated.push(...updatedResources);
            }
            toBeUpdated.forEach((r) => {
                lastModifiedHeaders[r.href] = r.lastModified;
                r.isNew = false;
                r.isUpdated = false;
            });
        }
        const updatedCourseData = {
            ...storedCourseData,
            seenResources: updatedSeenResources,
            newResources: updatedNewResources,
            lastModifiedHeaders,
        };
        logger.debug(updatedCourseData, "Storing updated course data in local storage");
        await chrome.storage.local.set({
            courseData: {
                ...courseData,
                [this.link]: updatedCourseData,
            },
        });
        return updatedCourseData;
    }
    async updateStoredActivities() {
        const { courseData } = (await chrome.storage.local.get("courseData"));
        const storedCourseData = courseData[this.link] ?? this.createCourseDataSnapshot();
        const { seenActivities, newActivities } = storedCourseData;
        logger.debug(newActivities, "Adding activities to list of seen activities");
        const updatedSeenActivities = Array.from(new Set(seenActivities.concat(newActivities)));
        const updatedNewActivities = [];
        const updatedCourseData = {
            ...storedCourseData,
            seenActivities: updatedSeenActivities,
            newActivities: updatedNewActivities,
        };
        await chrome.storage.local.set({
            courseData: {
                ...courseData,
                [this.link]: updatedCourseData,
            },
        });
        return updatedCourseData;
    }
    getNumberOfUpdates() {
        return [...this.resources, ...this.activities].filter((r) => r.isNew || r.isUpdated).length;
    }
    async processTiles(mainHTML) {
        const tiles = mainHTML.querySelectorAll("a.tile-link");
        if (tiles.length === 0)
            return;
        logger.debug(`Processing ${tiles.length} tiles for dynamic content via AJAX`);
        const sesskey = this.getSesskey();
        const contextId = this.getContextId();
        if (!sesskey || !contextId) {
            logger.warn("Could not find sesskey or contextid, falling back to visual clicks");
            for (const tile of Array.from(tiles)) {
                tile.click();
                await new Promise((r) => setTimeout(r, 500));
            }
            return;
        }
        const hiddenContainer = this.HTMLDocument.createElement("div");
        hiddenContainer.style.display = "none";
        mainHTML.appendChild(hiddenContainer);
        await Promise.all(Array.from(tiles).map(async (tile) => {
            const sectionId = new URL(tile.href).searchParams.get("id");
            if (!sectionId)
                return;
            try {
                const content = await this.fetchTileContent(sectionId, sesskey, contextId);
                if (!content)
                    return;
                const wrapper = this.HTMLDocument.createElement("div");
                wrapper.id = `section-${sectionId}`;
                const title = (tile.closest(".tile") || tile).querySelector("h3")?.textContent?.trim() || `Section ${sectionId}`;
                wrapper.setAttribute("aria-label", title);
                wrapper.innerHTML = content;
                hiddenContainer.appendChild(wrapper);
            }
            catch (e) {
                logger.error(`Failed to fetch tile content for section ${sectionId}`, e);
            }
        }));
    }
    getScriptContent() {
        return Array.from(this.HTMLDocument.scripts).map((s) => s.textContent).join(" ");
    }
    getSesskey() {
        const match = this.getScriptContent().match(/"sesskey":"([^"]+)"/);
        if (match)
            return match[1];
        const logoutLink = this.HTMLDocument.querySelector('a[href*="login/logout.php?sesskey="]');
        return logoutLink ? new URL(logoutLink.href).searchParams.get("sesskey") ?? undefined : undefined;
    }
    getContextId() {
        const match = this.getScriptContent().match(/"contextid":(\d+)/);
        if (match)
            return match[1];
        return this.HTMLDocument.body.className.match(/context-(\d+)/)?.[1];
    }
    async fetchTileContent(sectionId, sesskey, contextId) {
        const baseURL = getMoodleBaseURL(this.link);
        const response = await fetch(`${baseURL}/lib/ajax/service.php?sesskey=${sesskey}&info=core_get_fragment`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify([{
                    index: 0,
                    methodname: "core_get_fragment",
                    args: {
                        component: "format_tiles",
                        callback: "get_cm_list",
                        contextid: parseInt(contextId),
                        args: [{ name: "sectionid", value: parseInt(sectionId) }],
                    },
                }]),
        });
        if (!response.ok)
            return undefined;
        const data = await response.json();
        return data[0]?.data?.html;
    }
}
/* harmony default export */ const models_Course = (Course);

;// CONCATENATED MODULE: ./src/content-scripts/coursePage.ts





function sendScanResults(course) {
    chrome.runtime.sendMessage({
        command: constants_COMMANDS.SCAN_RESULT,
        course: {
            resources: course.resources,
            activities: course.activities,
        },
    });
}
async function initCoursePage() {
    const { options } = (await chrome.storage.local.get("options"));
    const courseLink = parseCourseLink(location.href);
    const course = new models_Course(courseLink, document, options);
    let initialScanCompleted = false;
    course
        .scan()
        .then(() => {
        updateIconFromCourses([course]);
        initialScanCompleted = true;
        sendScanResults(course);
    })
        .catch((err) => {
        logger.error(err);
        sendLog({ errorMessage: err.message, url: location.href, page: "course" });
        chrome.runtime.sendMessage({
            command: constants_COMMANDS.ERROR_VIEW,
        });
    });
    chrome.runtime.onMessage.addListener(async (message) => {
        const { command } = message;
        if (command === constants_COMMANDS.INIT_SCAN) {
            if (initialScanCompleted) {
                sendScanResults(course);
            }
            return;
        }
        if (command === constants_COMMANDS.MARK_AS_SEEN) {
            await course.updateStoredResources();
            await course.updateStoredActivities();
            await course.scan();
            updateIconFromCourses([course]);
            return;
        }
        if (command === constants_COMMANDS.UPDATE_ACTIVITIES) {
            await course.updateStoredActivities();
            await course.scan();
            updateIconFromCourses([course]);
            return;
        }
        if (command === constants_COMMANDS.COURSE_CRAWL) {
            const { options, selectedResources } = message;
            chrome.runtime.sendMessage({
                command: constants_COMMANDS.DOWNLOAD,
                id: getCourseDownloadId(command, course),
                courseName: course.name,
                courseShortcut: course.shortcut,
                courseLink: course.link,
                resources: selectedResources,
                options,
            });
            await course.updateStoredResources(selectedResources);
            await course.scan();
            updateIconFromCourses([course]);
        }
        if (command === constants_COMMANDS.ENSURE_CORRECT_BADGE) {
            updateIconFromCourses([course]);
        }
    });
}
const isMoodlePage = checkForMoodle();
if (isMoodlePage) {
    initCoursePage();
}

})();

/******/ })()
;