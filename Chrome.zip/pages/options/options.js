/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/shared/regexHelpers.ts
const validURLRegex = /https?:\/\/((www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b|localhost(:\d+)?)/gi;
const loginPageRegex = /\/login\/index.php/gi;
const dashboardPageRegex = /\/my/gi;
const coursePageRegex = /\/course\/(view|section)\.php\?id=[0-9]*/gi;
const courseResourcesPageRegex = /\/course\/resources\.php\?id=[0-9]*/gi;
const assignmentPageRegex = /\/mod\/assign\/view\.php\?(?=[^#]*\bid=[0-9]+)[^#]*/gi;
const videoServicePageRegex = /\/mod\/videoservice\/view\.php/gi;
const fileRegex = /\/mod\/resource\/view\.php\?id=[0-9]*/gi;
const folderRegex = /\/mod\/folder\/view\.php\?id=[0-9]*/gi;
const pluginFileRegex = /\/pluginfile\.php([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
const urlRegex = /\/mod\/url\/view\.php\?id=[0-9]*/gi;
const activityRegex = /\/mod\/(?!resource|folder)[A-z]*\/.*\.php.*/gi;
const allRegexes = {
    login: loginPageRegex,
    dashboard: dashboardPageRegex,
    course: coursePageRegex,
    courseResources: courseResourcesPageRegex,
    assignment: assignmentPageRegex,
    videoservice: videoServicePageRegex,
    file: fileRegex,
    folder: folderRegex,
    pluginfile: pluginFileRegex,
    url: urlRegex,
    activity: activityRegex,
};
function getURLRegex(type) {
    const baseUrlRegex = validURLRegex.source;
    const typeSpecificRegex = allRegexes[type].source;
    const regex = `${baseUrlRegex}.*${typeSpecificRegex}`;
    return new RegExp(regex, "gi");
}
function getMoodleBaseURL(string) {
    for (const regex of Object.values(allRegexes)) {
        const baseURLRegex = new RegExp(`.*(?=${regex.source})`);
        const match = string.match(baseURLRegex);
        if (match) {
            return match[0];
        }
    }
    return "";
}

;// CONCATENATED MODULE: ./src/shared/constants.ts
const COMMANDS = {
    GET_STATE: "GET_STATE",
    STATE: "STATE",
    EVENT: "EVENT",
    PAGE_DATA: "PAGE_DATA",
    FEEDBACK: "FEEDBACK",
    SET_BADGE: "SET_BADGE",
    SET_ICON: "SET_ICON",
    ERROR_VIEW: "ERROR_VIEW",
    LOG: "LOG",
    EXECUTE_SCRIPT: "EXECUTE_SCRIPT",
    COURSE_CRAWL: "COURSE_CRAWL",
    DASHBOARD_DOWNLOAD_NEW: "DASHBOARD_DOWNLOAD_NEW",
    SCAN_IN_PROGRESS: "SCAN_IN_PROGRESS",
    INIT_SCAN: "INIT_SCAN",
    SCAN_RESULT: "SCAN_RESULT",
    MARK_AS_SEEN: "MARK_AS_SEEN",
    CANCEL_DOWNLOAD: "CANCEL_DOWNLOAD",
    UPDATE_ACTIVITIES: "UPDATE_ACTIVITIES",
    DOWNLOAD: "DOWNLOAD",
    DOWNLOAD_PROGRESS: "DOWNLOAD_PROGRESS",
    VIDEO_DOWNLOAD_PROGRESS: "VIDEO_DOWNLOAD_PROGRESS",
    CLEAR_COURSE_DATA: "CLEAR_COURSE_DATA",
    RATE_CLICK: "RATE_CLICK",
    AVOID_RATE_CLICK: "AVOID_RATE_CLICK",
    CLEAR_COURSE: "CLEAR_COURSE",
    TRACK_PAGE_VIEW: "TRACK_PAGE_VIEW",
    ENSURE_CORRECT_BADGE: "ENSURE_CORRECT_BADGE",
    BACKGROUND_SCAN: "BACKGROUND_SCAN",
    CHECK_BACKGROUND_SCAN: "CHECK_BACKGROUND_SCAN",
    RESET_STORAGE: "RESET_STORAGE",
    BG_COURSE_SCAN: "BG_COURSE_SCAN",
    BG_COURSE_SCAN_RESULT: "BG_COURSE_SCAN_RESULT",
    DEV_CLEAR_SEEN_RESOURCES: "DEV_CLEAR_SEEN_RESOURCES",
    DOWNLOAD_ALL: "DOWNLOAD_ALL",
    DASHBOARD_DOWNLOAD_COURSE: "DASHBOARD_DOWNLOAD_COURSE",
    DASHBOARD_UPDATE_COURSE: "DASHBOARD_UPDATE_COURSE",
    GET_DOWNLOAD_STATE: "GET_DOWNLOAD_STATE",
};

;// CONCATENATED MODULE: ./src/pages/options/options.ts


let restoredOptions;
async function restore() {
    chrome.storage.local.get("options").then(({ options }) => {
        restoredOptions = options;
        const inputs = document.querySelectorAll("input");
        inputs.forEach((input) => {
            switch (input.type) {
                case "checkbox":
                    input.checked = options[input.id];
                    break;
                case "radio":
                    input.checked = input.value === options[input.name];
                    break;
                default:
                    input.value = options[input.id];
                    break;
            }
        });
        document.getElementById("defaultMoodleURL")?.dispatchEvent(new Event("input"));
    });
}
let timeout;
async function save(e) {
    e.preventDefault();
    const updatedOptions = {};
    const inputs = document.querySelectorAll("input");
    inputs.forEach((input) => {
        switch (input.type) {
            case "checkbox":
                updatedOptions[input.id] = input.checked;
                break;
            case "number":
                updatedOptions[input.id] = parseFloat(input.value);
                break;
            case "radio":
                if (input.checked) {
                    updatedOptions[input.name] = input.value;
                }
                break;
            default:
                updatedOptions[input.id] = input.value;
                break;
        }
    });
    const changedOptions = {};
    for (const option of Object.keys(updatedOptions)) {
        if (updatedOptions[option] !== restoredOptions[option]) {
            changedOptions[option] = {
                old: restoredOptions[option],
                new: updatedOptions[option],
            };
        }
    }
    clearTimeout(timeout);
    timeout = setTimeout(async () => {
        await chrome.runtime.sendMessage({
            command: COMMANDS.EVENT,
            event: "modify-options",
            saveURL: false,
            eventData: changedOptions,
        });
    }, 500);
    if (updatedOptions.disableInteractionTracking) {
        await chrome.runtime.sendMessage({
            command: COMMANDS.EVENT,
            event: "disable-tracking",
            saveURL: false,
        });
    }
    await chrome.storage.local.set({
        options: updatedOptions,
    });
}
function checkURL(e) {
    const target = e.target;
    const inputURL = target.value;
    const invalidURLHint = document.querySelector("#invalid-url");
    if (invalidURLHint) {
        if (inputURL !== "" && !inputURL.match(validURLRegex)) {
            invalidURLHint.style.display = "block";
        }
        else {
            invalidURLHint.style.display = "none";
        }
    }
}
async function clearCourseData(e) {
    await chrome.runtime.sendMessage({
        command: COMMANDS.CLEAR_COURSE_DATA,
    });
    const target = e.target;
    target.disabled = true;
}
document.addEventListener("DOMContentLoaded", restore);
document.addEventListener("input", save);
document.getElementById("defaultMoodleURL")?.addEventListener("input", checkURL);
document.getElementById("clear-button")?.addEventListener("click", clearCourseData);

/******/ })()
;