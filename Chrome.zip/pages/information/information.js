/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/shared/constants.ts
const COMMANDS = {
    GET_STATE: "GET_STATE",
    STATE: "STATE",
    EVENT: "EVENT",
    PAGE_DATA: "PAGE_DATA",
    FEEDBACK: "FEEDBACK",
    SET_BADGE: "SET_BADGE",
    SET_ICON: "SET_ICON",
    ERROR_VIEW: "ERROR_VIEW",
    LOG: "LOG",
    EXECUTE_SCRIPT: "EXECUTE_SCRIPT",
    COURSE_CRAWL: "COURSE_CRAWL",
    DASHBOARD_DOWNLOAD_NEW: "DASHBOARD_DOWNLOAD_NEW",
    SCAN_IN_PROGRESS: "SCAN_IN_PROGRESS",
    INIT_SCAN: "INIT_SCAN",
    SCAN_RESULT: "SCAN_RESULT",
    MARK_AS_SEEN: "MARK_AS_SEEN",
    CANCEL_DOWNLOAD: "CANCEL_DOWNLOAD",
    UPDATE_ACTIVITIES: "UPDATE_ACTIVITIES",
    DOWNLOAD: "DOWNLOAD",
    DOWNLOAD_PROGRESS: "DOWNLOAD_PROGRESS",
    VIDEO_DOWNLOAD_PROGRESS: "VIDEO_DOWNLOAD_PROGRESS",
    CLEAR_COURSE_DATA: "CLEAR_COURSE_DATA",
    RATE_CLICK: "RATE_CLICK",
    AVOID_RATE_CLICK: "AVOID_RATE_CLICK",
    CLEAR_COURSE: "CLEAR_COURSE",
    TRACK_PAGE_VIEW: "TRACK_PAGE_VIEW",
    ENSURE_CORRECT_BADGE: "ENSURE_CORRECT_BADGE",
    BACKGROUND_SCAN: "BACKGROUND_SCAN",
    CHECK_BACKGROUND_SCAN: "CHECK_BACKGROUND_SCAN",
    RESET_STORAGE: "RESET_STORAGE",
    BG_COURSE_SCAN: "BG_COURSE_SCAN",
    BG_COURSE_SCAN_RESULT: "BG_COURSE_SCAN_RESULT",
    DEV_CLEAR_SEEN_RESOURCES: "DEV_CLEAR_SEEN_RESOURCES",
    DOWNLOAD_ALL: "DOWNLOAD_ALL",
    DASHBOARD_DOWNLOAD_COURSE: "DASHBOARD_DOWNLOAD_COURSE",
    DASHBOARD_UPDATE_COURSE: "DASHBOARD_UPDATE_COURSE",
    GET_DOWNLOAD_STATE: "GET_DOWNLOAD_STATE",
};

;// CONCATENATED MODULE: ./src/pages/information/information.ts

document.querySelector("#imprint-link")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({
        command: COMMANDS.EVENT,
        event: "imprint-click",
        saveURL: false,
    });
    chrome.tabs.create({
        url: "/pages/legal/legal.html",
    });
});
document.querySelector("#privacy-link")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({
        command: COMMANDS.EVENT,
        event: "privacy-click",
        saveURL: false,
    });
    chrome.tabs.create({
        url: "/pages/legal/legal.html",
    });
});
document.querySelectorAll(".options-link")?.forEach((n) => {
    n.addEventListener("click", () => {
        chrome.runtime.sendMessage({
            command: COMMANDS.EVENT,
            event: "options-click",
            saveURL: false,
        });
        chrome.runtime.openOptionsPage();
    });
});
document.querySelector("#donate-link")?.addEventListener("click", () => {
    chrome.runtime.sendMessage({
        command: COMMANDS.EVENT,
        event: "donate-click",
        saveURL: false,
    });
});
document.querySelectorAll(".contact-link")?.forEach((n) => {
    n.addEventListener("click", () => {
        chrome.tabs.create({
            url: "/pages/contact/contact.html",
        });
    });
});
const versionSpan = document.querySelector("#version");
if (versionSpan) {
    versionSpan.textContent = `(v. ${chrome.runtime.getManifest().version})`;
}

/******/ })()
;