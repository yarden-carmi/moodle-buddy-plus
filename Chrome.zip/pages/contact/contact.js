/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/shared/constants.ts
const COMMANDS = {
    GET_STATE: "GET_STATE",
    STATE: "STATE",
    EVENT: "EVENT",
    PAGE_DATA: "PAGE_DATA",
    FEEDBACK: "FEEDBACK",
    SET_BADGE: "SET_BADGE",
    SET_ICON: "SET_ICON",
    ERROR_VIEW: "ERROR_VIEW",
    LOG: "LOG",
    EXECUTE_SCRIPT: "EXECUTE_SCRIPT",
    COURSE_CRAWL: "COURSE_CRAWL",
    DASHBOARD_DOWNLOAD_NEW: "DASHBOARD_DOWNLOAD_NEW",
    SCAN_IN_PROGRESS: "SCAN_IN_PROGRESS",
    INIT_SCAN: "INIT_SCAN",
    SCAN_RESULT: "SCAN_RESULT",
    MARK_AS_SEEN: "MARK_AS_SEEN",
    CANCEL_DOWNLOAD: "CANCEL_DOWNLOAD",
    UPDATE_ACTIVITIES: "UPDATE_ACTIVITIES",
    DOWNLOAD: "DOWNLOAD",
    DOWNLOAD_PROGRESS: "DOWNLOAD_PROGRESS",
    VIDEO_DOWNLOAD_PROGRESS: "VIDEO_DOWNLOAD_PROGRESS",
    CLEAR_COURSE_DATA: "CLEAR_COURSE_DATA",
    RATE_CLICK: "RATE_CLICK",
    AVOID_RATE_CLICK: "AVOID_RATE_CLICK",
    CLEAR_COURSE: "CLEAR_COURSE",
    TRACK_PAGE_VIEW: "TRACK_PAGE_VIEW",
    ENSURE_CORRECT_BADGE: "ENSURE_CORRECT_BADGE",
    BACKGROUND_SCAN: "BACKGROUND_SCAN",
    CHECK_BACKGROUND_SCAN: "CHECK_BACKGROUND_SCAN",
    RESET_STORAGE: "RESET_STORAGE",
    BG_COURSE_SCAN: "BG_COURSE_SCAN",
    BG_COURSE_SCAN_RESULT: "BG_COURSE_SCAN_RESULT",
    DEV_CLEAR_SEEN_RESOURCES: "DEV_CLEAR_SEEN_RESOURCES",
    DOWNLOAD_ALL: "DOWNLOAD_ALL",
    DASHBOARD_DOWNLOAD_COURSE: "DASHBOARD_DOWNLOAD_COURSE",
    DASHBOARD_UPDATE_COURSE: "DASHBOARD_UPDATE_COURSE",
    GET_DOWNLOAD_STATE: "GET_DOWNLOAD_STATE",
};

;// CONCATENATED MODULE: ./src/pages/contact/contact.ts

document.querySelector("#form-button")?.addEventListener("click", async () => {
    const email = document.querySelector("#form-email")?.value;
    const platform = document.querySelector("#form-platform")?.value;
    const subject = document.querySelector("#form-subject")?.value;
    const content = document.querySelector("#form-content")?.value;
    if (subject && content && platform) {
        const { options, browserId } = (await chrome.storage.local.get());
        const { defaultMoodleURL } = options;
        const message = [
            `E-Mail: ${email}`,
            `Moodle platform: ${platform}`,
            `Browser ID: ${browserId}`,
            `Moodle URL: ${defaultMoodleURL}`,
            content,
        ].join("\n\n");
        chrome.runtime.sendMessage({
            command: COMMANDS.FEEDBACK,
            feedbackData: { subject, content: message },
        });
        const sectionContent = document.querySelector(".section-content");
        if (sectionContent)
            sectionContent.style.display = "none";
        const successMessage = document.querySelector(".success");
        if (successMessage)
            successMessage.style.display = "flex";
    }
    else {
        const missingHint = document.querySelector(".missing");
        if (missingHint)
            missingHint.style.display = "block";
    }
});
const versionSpan = document.querySelector("#version");
if (versionSpan) {
    versionSpan.textContent = `(v. ${chrome.runtime.getManifest().version})`;
}

/******/ })()
;