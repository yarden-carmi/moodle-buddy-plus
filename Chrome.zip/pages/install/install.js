/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
document.querySelector("#info")?.addEventListener("click", () => {
    chrome.tabs.create({
        url: "/pages/information/information.html",
    });
});
const versionSpan = document.querySelector("#version");
if (versionSpan) {
    versionSpan.textContent = `(v. ${chrome.runtime.getManifest().version})`;
}


/******/ })()
;